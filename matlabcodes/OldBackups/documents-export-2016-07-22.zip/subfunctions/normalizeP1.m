function NP1=normalizeP1(P1,bounds)
    NP1=gdivide(P1,bounds)
end