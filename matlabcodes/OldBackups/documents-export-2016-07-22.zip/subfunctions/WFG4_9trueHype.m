function val=WFG4_9trueHype(wfg_no,dim,bounds)

    V2=prod(bounds);
    
    

end

function V1=evenV1()

end

function V1=oddV1()

end