for i=1:100
    string=strcat('something',num2str(i),'others');
    disp(string);
end