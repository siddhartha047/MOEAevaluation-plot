
[m,n]=size(Global)
x=Global(1:m,1);
y=Global(1:m,2);
z=Global(1:m,3);
scatter3(x,y,z,'black');
